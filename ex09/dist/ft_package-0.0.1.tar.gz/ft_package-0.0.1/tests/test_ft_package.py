import unittest
from ft_package.module import count_in_list

class TestModule1(unittest.TestCase):
    def test_function1(self):
        self.assertEqual(count_in_list(), "Hello from ft_package module")

if __name__ == '__main__':
    unittest.main()